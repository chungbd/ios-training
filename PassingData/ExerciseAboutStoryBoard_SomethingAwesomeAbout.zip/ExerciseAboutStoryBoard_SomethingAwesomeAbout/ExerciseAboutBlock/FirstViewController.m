//
//  FirstViewController.m
//  ExerciseAboutBlock
//
//  Created by Chung BD on 8/7/16.
//  Copyright © 2016 Chung BD. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"

#define segueIdentify @"SegueFromFirstToSecond"

@interface FirstViewController ()


@end

@implementation FirstViewController

#pragma mark - life cycle of view
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)viewWillAppear:(BOOL)animated {
    if (self.storedName) {
        self.lblName.text = self.storedName;
    }
}

- (void) viewDidAppear:(BOOL)animated {
//    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

#pragma mark - IBAction
- (IBAction)touchUpInside_btnNext:(id)sender {
    [self goToSecondViewController];
}

#pragma mark - Public methods


#pragma mark - Private methods
- (void) goToSecondViewController {
//    SecondViewController *second = [SecondViewController newViewController];
//    second.firstVC = self;
//    [self presentViewController:second animated:YES completion:nil];
}



#pragma mark - Navigation
- (IBAction)unwindToFirstScreen:(UIStoryboardSegue*)sender{
    SecondViewController *sourceViewController = sender.sourceViewController;
    // Pull any data from the view controller which initiated the unwind segue.
    self.lblName.text = sourceViewController.txtName.text;
}


// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:segueIdentify]) {
        SecondViewController *destinationVC = segue.destinationViewController;
        
    }
    
}


@end
